from __future__ import print_function
import time
import uuid
import sys
import socket
import elasticache_auto_discovery
import redis
import csv
import os

##### GLOBAL VARIABLES #####

#TODO: Replace with the redis dns endpoint
aws_dns_endpoint = "Replace-with-redis-dns endpoint"
block_num_arr = []


def predict_rf(client, X, num_bins, num_classes):
    """
    Predicts label for a test observation
    one at a time
    :param redis client and X
    :returns predicted label
    """

    preds = [0] * num_classes

    for bin_no in range(num_bins):
        curr_node = [i for i in tree_start[bin_no]]

        while True:
            number_not_in_leaf = 0
            for i in range(bin_sizes[bin_no]):
                if curr_node[i] >= 0:
                    left, right, feature, threshold =\
                            getBlockNodeFromDB(client, curr_node[i], bin_no)
                    if left > -1 :
                        obs_feature_val = X[feature]
                        if obs_feature_val <= threshold:
                            curr_node[i] = left
                        else:
                            curr_node[i] = right
                        number_not_in_leaf += 1

            if number_not_in_leaf <= 0:
                break

        for i in range(bin_sizes[bin_no]):
            left, class_label, feature, threshold =\
                            getBlockNodeFromDB(client, curr_node[i], bin_no)
            preds[class_label] += 1

    return np.argmax(preds)


def predict_gb(client, X):
    preds = [0] * num_classes
    pred_val=0
    for bin_no in range(num_bins):
        curr_node = [j for j in tree_start[bin_no]]

        while True:
            number_not_in_leaf = 0
            for i in range(bin_sizes[bin_no]):
                if curr_node[i] >= 0:
                    left, right, feature, threshold =\
                            getBlockNodeFromDB(client, curr_node[i], bin_no)
                    if left > -1:
                        obs_feature_val = X[feature]
                        if obs_feature_val <= threshold:
                            curr_node[i] = left
                        else:
                            curr_node[i] = right
                        number_not_in_leaf += 1

            if number_not_in_leaf <= 0:
                break

        for i in range(bin_sizes[bin_no]):
            left, right, feature, threshold =\
                            getBlockNodeFromDB(client, curr_node[i], bin_no)

            pred_val += threshold

    if pred_val > 0:
        return 1 
    return 0


def getNodeFromDB(client, node_id):
    left = int(float(client.hget(node_id, 'left')))
    right = int(float(client.hget(node_id, 'right')))
    feature = int(float(client.hget(node_id, 'feature'))) 
    threshold = float(client.hget(node_id, 'threshold'))
    return left, right, feature, threshold


def clearCache():
    cached_node_hash = [{} for i in range(num_bins)]


def getBlockNodeFromDB(client, node_id, bin_num):
    global tot_num_blocks
    global redis_tot
    global tot_acc
    if node_id not in cached_node_hash[bin_num]:
        tot_num_blocks+=1
        block_num = int(node_id / blocksize)
        block_num_arr.append(block_num)
        key_str = str(bin_num) + ':' + str(block_num)
        block_num_arr.append(key_str)
        time_start = time.time()
        nodes = client.lrange(key_str, 0, -1)
        time_end = time.time()
        redis_tot += (time_end - time_start)
        tot_acc+=1
        siz = len(nodes)
        for i in range(0, siz, 5):
            node = ( int(float(nodes[i+1])), int(float(nodes[i+2])),
                    int(float(nodes[i+3])), float(nodes[i+4]) )
            cached_node_hash[bin_num][int(float(nodes[i]))] = node
    return cached_node_hash[bin_num][node_id]



def predict_rf(client, X):
    """
    Predicts label for a test observation
    one at a time
    :param redis client and X
    :returns predicted label
    """
    
    preds = [0] * num_classes
    
    for bin_no in range(num_bins):
        curr_node = [j for j in tree_start[bin_no]]
        
        while True:
            number_not_in_leaf = 0
            for i in range(bin_sizes[bin_no]):
                if curr_node[i] >= 0:
                    left, right, feature, threshold =\
                            getBlockNodeFromDB(client, curr_node[i], bin_no)
                    if left > -1:
                        obs_feature_val = X[feature]
                        if obs_feature_val <= threshold:
                            curr_node[i] = left
                        else:
                            curr_node[i] = right
                        number_not_in_leaf += 1
        
            if number_not_in_leaf <= 0:
                break

        for i in range(bin_sizes[bin_no]):
            left, class_label, feature, threshold =\
                            getBlockNodeFromDB(client, curr_node[i], bin_no)
            preds[class_label] += 1 
    
    return preds.index(max(preds))


def validatePredictions(predicted, y):
    right = 0
    total = 0
    for i, j in zip(predicted, y):
        if i==j:
            right+=1
        total+=1

    return float(right) / float(total)


def writeToFile(timing_lists, head_dir, filenames):
    print('entered')
    full_paths = [os.path.join(head_dir, filename) for filename in filenames]
    for path, timing_list in zip(full_paths, timing_lists):
        with open(path, "wb") as file:
            writer = csv.writer(file, delimiter=',')
            writer.writerow(timing_list)

def lambda_handler(event, context):
    """
    This function puts into memcache and get from it.
    Memcache is hosted using elasticache
    """

    #Global variables 
    global num_classes
    global num_observations
    global num_features
    global num_trees
    global num_bins
    global tree_start
    global blocksize
    global bin_sizes
    global bin_node_sizes
    global cached_node_hash
    global tot_num_blocks
    global redis_tot
    global tot_acc
    redis_tot = 0
    tot_acc = 0
    db_id = int(event['db'])
    tree_start = []
    bin_sizes = []
    bin_node_sizes = []

    cached_node_hash = []
    
    #Create Redis clients
    redisClientObservation = redis.StrictRedis(host=aws_dns_endpoint,
                                        port=6379,
                                        db=0)

    redisClientLabel = redis.StrictRedis(host=aws_dns_endpoint,
                                        port=6379,
                                        db=1)

    redisClientMeta = redis.StrictRedis(host=aws_dns_endpoint,
                                        port=6379,
                                        db=db_id)
    
    #Get Metadata
    num_classes = int(float(redisClientMeta.get("num_classes")))
    num_observations = int(float(redisClientMeta.get("num_observations")))
    num_features = int(float(redisClientMeta.get("num_features")))
    num_bins = int(float(redisClientMeta.get("num_bins")))
    blocksize = int(float(redisClientMeta.get("block_size")))
    #print("num classes: ")
    #print(num_classes)
    bin_sizes_str = redisClientMeta.lrange("bin_sizes", 0, -1)
    bin_sizes = [int(float(i)) for i in bin_sizes_str]
    
    bin_node_sizes_str = redisClientMeta.lrange("bin_node_sizes", 0, -1)
    bin_node_sizes = [int(float(i)) for i in bin_node_sizes_str]

    tree_start = []
    for bin_no in range(num_bins):
        tree_start_str = redisClientMeta.lrange("tree_start:" + str(bin_no), 0, -1)
        tree_start_flat = [int(float(i)) for i in tree_start_str]
        tree_start.append(tree_start_flat)
        
    cached_node_hash = [{} for i in range(num_bins)]

    #Predict labels for test data
    predicted = []
    times = []
    times.append([])
    db_ids = []
    db_ids.append(db_id)
    avg_red_time = []
    num_b_arr = []
    tot_num_blocks = 0
    for j in range(num_test_obs):
        for counter, db_id in enumerate(db_ids):
            clearCache()
            redisClientForest = redis.StrictRedis(host=aws_dns_endpoint,
                                        port=6379,
                                        db=db_id)
            row_db = redisClientObservation.lrange(j, 0, num_features)
            row = [float(i) for i in row_db]
            time_start = time.time()
            #TODO: Change to predict_rf for random forests
            predict_value = predict_gb(redisClientForest, row)
            time_end = time.time()
            times[counter].append(time_end - time_start)
            block_num_arr.clear()
            num_b_arr.append(tot_num_blocks)
            avg_red_time.append(float(redis_tot) / float(tot_acc))
            tot_num_blocks = 0
            redis_tot = 0
            tot_acc = 0
    
    for arr in times:
        print(arr)
        print("*********************************************")
    print("blocks arr: ")
    print (num_b_arr)
    print("redis  time: ")
    print(avg_red_time)
    #writeToFile(times, head_dir, filenames)
