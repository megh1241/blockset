#TODO: populate dns-endpoint in redis_app.py

zip -r function.zip redis_app.py

aws lambda create-function --function-name $1 --timeout 900 --memory-size 1024 --zip-file fileb://function.zip --handler redis_app.lambda_handler --runtime python3.8 --role "Replace with your role" --vpc-config SubnetIds="Replace with subnets",SecurityGroupIds="Replace with security groups"
sleep 50
aws lambda invoke --function-name $1 --invocation-type Event --payload '{ "db":2}' out1.txt --log-type Tail --query 'LogResult' --output text |  base64 -d > out1
sleep 2500

aws lambda invoke --function-name $1 --invocation-type Event --payload '{ "db":3}' out2.txt --log-type Tail --query 'LogResult' --output text |  base64 -d > out2

sleep 2500

aws lambda invoke --function-name $1 --invocation-type Event --payload '{ "db":4}' out3.txt --log-type Tail --query 'LogResult' --output text |  base64 -d > out3

sleep 2500

aws lambda invoke --function-name $1 --invocation-type Event --payload '{ "db":5}' out4.txt --log-type Tail --query 'LogResult' --output text |  base64 -d > out4

sleep 2500
aws lambda invoke --function-name $1 --invocation-type Event --payload '{ "db":6}' out5.txt --log-type Tail --query 'LogResult' --output text |  base64 -d > out5

sleep 2500
aws lambda invoke --function-name $1 --invocation-type Event --payload '{ "db":7}' out6.txt --log-type Tail --query 'LogResult' --output text |  base64 -d > out6
sleep 2500
aws lambda invoke --function-name $1 --invocation-type Event --payload '{ "db":10}' out6.txt --log-type Tail --query 'LogResult' --output text |  base64 -d > out6
